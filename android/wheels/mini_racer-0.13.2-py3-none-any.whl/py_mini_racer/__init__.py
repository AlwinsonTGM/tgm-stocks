"""Android stub for mini-racer.

V8 has no Android build for this project, so akshare's JavaScript-backed
endpoints cannot run here. Everything else in akshare is unaffected: this
module imports cleanly and only fails when a caller constructs a MiniRacer.
"""

__version__ = "0.13.2"


class MiniRacer:
    """Placeholder that refuses to run JavaScript on Android."""

    def __init__(self, *args, **kwargs):
        raise RuntimeError(
            "mini-racer (V8) is not available on Android. This akshare endpoint "
            "needs JavaScript evaluation and cannot run on this device."
        )
